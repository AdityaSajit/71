import firebase from 'firebase'

const firebaseConfig = {
 apiKey: "AIzaSyBfNWiHw9NLdid_0X_HJn2rA3cgZveBT44",
  authDomain: "quiz-buzzer-app-90476.firebaseapp.com",
  databaseURL: "https://quiz-buzzer-app-90476-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "quiz-buzzer-app-90476",
  storageBucket: "quiz-buzzer-app-90476.appspot.com",
  messagingSenderId: "1099368271955",
  appId: "1:1099368271955:web:39c43f2897856a7ee8b6a6"
 
};
  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore()

